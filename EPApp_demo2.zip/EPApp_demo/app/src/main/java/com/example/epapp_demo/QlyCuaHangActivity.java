package com.example.epapp_demo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.epapp_demo.DAO.CuaHangDAO;
import com.example.epapp_demo.DAO.KhachHangDAO;
import com.example.epapp_demo.adapter.CuaHangAdapter;
import com.example.epapp_demo.model.CuaHang;
import com.example.epapp_demo.model.KhachHang;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

public class QlyCuaHangActivity extends AppCompatActivity {

    CuaHangDAO cuaHangDAO = new CuaHangDAO(this);
    public static CuaHangAdapter cuaHangAdapte;
    ListView lv;
    ArrayList<CuaHang> list = new ArrayList<>();
    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qly_cua_hang);

        lv = findViewById(R.id.rcvQlyCH);
        add = findViewById(R.id.btnAddCH);


        list = cuaHangDAO.getAll();
        cuaHangAdapte = new CuaHangAdapter(QlyCuaHangActivity.this,list);
        lv.setAdapter(cuaHangAdapte);
        Log.d("test1", String.valueOf(list));

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(QlyCuaHangActivity.this);
                View view1 = getLayoutInflater().inflate(R.layout.add_cuahang,null);
                final EditText tenCH = view1.findViewById(R.id.edtNameStore);
                final EditText mailCH = view1.findViewById(R.id.edtMailStore);
                final EditText passCH = view1.findViewById(R.id.edtPassStore);
                builder.setView(view1);
                builder.setPositiveButton("Thêm", new DialogInterface.OnClickListener() {
                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        String tenCH1 = tenCH.getText().toString();
                        String mailCH1 = mailCH.getText().toString();
                        String passCH1 = passCH.getText().toString();
                        CuaHang s = new CuaHang(mailCH1,passCH1,null, tenCH1,"",null,"",null,null);
                        cuaHangDAO.insert(s);
                    }
                });
                builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.setView(view1);
                builder.show();
            }
        });
    }
}